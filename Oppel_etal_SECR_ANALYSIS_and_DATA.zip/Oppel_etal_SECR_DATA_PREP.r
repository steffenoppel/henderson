#######################################################################################
##  RAT SURVIVAL ESTIMATION ON HENDERSON ISLAND  - DATA PREPARATION FOR SPATIAL CJS MODEL ##
#######################################################################################

#### supplementary code to:

# Oppel, S., McClelland, G.T.W., Lavers, J.L., Churchyard, T., Donaldson, A.H., Duffield, N.D., Havery, S., Kelly, J., Proud, T., Russell, J., Vickery, J.A. & Bond, A.L. (2017).
# 'Seasonal variation in movements and survival of Pacific Rats on Henderson Island'.
# Proceedings of the Island Invasives 2017 Conference. pp. x-x.



#### version history:

## written by steffen.oppel@rspb.org.uk on 22 July 2016
## based on book chapter 16.3 in Royle/Gardner/Sollmann book
## uses the primary periods as encounter occasions, and the number of secondary (daily) captures for each rat at each trap
## trapping effort is the number of active trap nights at each location
## UPDATE 23 July 2016: included sex and age of killed rats because number of individuals was too large for computer - REMOVED 28 NOVEMBER
## UPDATE 26 July 2016: added trap-specific recapture probability
## SHORTENED 21 Oct 2016 - temporarily abandoned on 24 OCT 2016
## RESUMED ON 25 NOV 2016 because all approaches using single nights as occasions (single session or robuist design models) produced ludicrous estimates.
## 25 NOV 2016: REMOVED AGE AND ADDED INDIVIDUAL CAPTURE HETEROGENEITY EFFECTS
## UPDATED ON 4 Jan 2017: INCLUDED PITCAIRN RAINFALL DATA AS COVARIATE
## UPDATED on 10 Jan to include extended rainfall metric (from non-spatial analysis)
## UPDATED 11 January 2017 TO INCLUDE SESSION 8 - SNAP TRAPPING
### UPDATED IN NEW VERSION ON 11 Dec 2017 after review: included reproductive status and NDVI instead of sex and rainfall




library(RODBC)
library(sp)
library(rgdal)
library(maptools)
library(reshape)
library(MODISTools)
library(tidyverse)


################################################################################################################
######################### INPUT DATA #############################################
################################################################################################################



setwd("S:\\ConSci\\DptShare\\SteffenOppel\\RSPB\\UKOT\\Henderson\\Data")
setwd("C:\\STEFFEN\\RSPB\\UKOT\\Henderson\\Data")
SP<-odbcConnectAccess2007('HendersonData_2015.accdb')
rats <- sqlQuery(SP, "SELECT * FROM SECR_rat_input_Gardner2010")
kills<-sqlQuery(SP, "SELECT * FROM Kill_rat_last_locs")
ratinds <- sqlQuery(SP, "SELECT * FROM Rat_individuals") 
trap <- sqlQuery(SP, "SELECT * FROM SECR_input_traps_Gardner2010")
sessions <- sqlQuery(SP, "SELECT * FROM Sessions")
traptypes <- sqlQuery(SP, "SELECT * FROM trap_deployments")
rainHEN <- sqlQuery(SP, "SELECT * FROM daily_rain")
odbcClose(SP)

head(rats)
head(trap)


#############################################################################
##   CREATE MATRIX FOR EACH INDIVIDUAL'S REPRODUCTIVE STATUS FOR EACH SESSION  ####
#############################################################################

statmatrix<- rats %>% filter(area=="Plateau") %>%
	select(Rat_ID,TrapSession,status) %>%
	mutate(rep=if_else(status %in% c("lactating","pregnant"),1,2)) %>%
	group_by(Rat_ID,TrapSession) %>%
	summarise(rep=min(rep)) %>%
	spread(key=TrapSession, value=rep)
rats$status<-NULL


#############################################################################
##   LOAD NDVI DATA FOR TRAPPING SESSIONS  ####
#############################################################################
### for download see Henderson_NDVI_analysis.R

savedir <- "A:\\RSPB\\UKOT\\Henderson\\Data\\MODIS" 			# You can save the downloaded File in a specific folder
NDVI<-MODISTimeSeries(Dir=savedir, Band="250m_16_days_NDVI", Simplify = FALSE)

## FORMAT DATE AND TIME OF NDVI
str(NDVI)
setwd(savedir)
NDVI<-melt(NDVI[[1]])
NDVI$Date<-as.Date(paste(substr(NDVI[,1],2,5),format(strptime(as.numeric(substr(NDVI[,1],6,8)),format="%j"),format="%m-%d"),sep="-"))
head(NDVI)

## provide time range for which NDVI data are needed
timerange<-seq(min(as.Date(sessions$Date)-10),max(as.Date(sessions$Date)+10),1)

NDVI<-NDVI %>% filter(Date %in% timerange) %>%
	filter(value > (-3000)) %>%
	group_by(Date) %>%
	summarise(NDVI=mean(value))

NDVIsess<- sessions %>% group_by(habitat,TrapSession) %>%
	summarise(start=min(Date), end=max(Date))
NDVIsess$NDVI<-c(
mean(NDVI$NDVI[6:7]),	## survival from 1/8 - 26/8
mean(NDVI$NDVI[7:8]),	## survival from 17/8 - 19/9
mean(NDVI$NDVI[7:8]),	## irrelevant for survival

mean(NDVI$NDVI[1:3]),	## survival from 29/5 - 24/6
mean(NDVI$NDVI[3:4]),	## survival from 15/6 - 16/7
mean(NDVI$NDVI[4:5]),	## survival from 6/7 - 5/8
mean(NDVI$NDVI[6:7]),	## survival from 27/7 - 30/8
mean(NDVI$NDVI[7:8]),	## survival from 20/8 - 19/9
mean(NDVI$NDVI[9:10]),	## survival from 10/9 - 16/10
mean(NDVI$NDVI[10:12]),	## survival from 1/10 - 14/11
mean(NDVI$NDVI[10:12]))	## irrelevant for survival


### Standardise for JAGS ###
NDVIinput<-NDVIsess %>% filter(habitat=="Plateau") %>%
		mutate(standNDVI=(NDVI-mean(NDVI))/(sd(NDVI)))




#############################################################################
##   LOAD WEATHER DATA FOR TRAPPING SESSIONS  ####
#############################################################################


## these data are provided by Pitcairn in an Excel file with two sheets per month
library(readxl)
setwd("A:\\RSPB\\UKOT\\Henderson\\Data\\Weather\\Pitcairn")
setwd("C:\\STEFFEN\\RSPB\\UKOT\\Henderson\\Data\\Weather\\Pitcairn")
files<-list.files(pattern = "\\.xlsx$")	
files[10]

rain<-data.frame()
for (sh in seq(5,10,1)){
shit<-read_excel(files[10], sh,col_names=F,skip=7)
shit<-as.data.frame(shit)
shit<-shit[,1:2]
del<-as.numeric(min(row.names(shit[is.na(shit[,1]),])))
delete<-seq(del,dim(shit)[1],1)
shit<-shit[-(delete),]
shit[,2]<-as.numeric(shit[,2])
shit$Month=sh
rain<-rbind(rain,shit)
}
names(rain)<-c("Day","mm","Month")
rain$Date<-as.POSIXct(paste("2015",rain$Month, rain$Day, sep="-"), format="%Y-%m-%d")


### CALCULATE SUM OF RAINFALL FOR EACH OCCASION AND HABITAT - AS CAPTURE COVARIATE
habs<-c("Beachback","Plateau")
sessrain<-matrix(0,ncol=2,nrow=8)
for (sess in 1:8){
	x<-sessions[sessions$TrapSession==sess,]
 for (a in 1:2){
	xa<-x[x$habitat==habs[a],]
	if(dim(xa)[1]>0){sessrange<-seq.Date(as.Date(min(xa$Date, na.rm=T)),as.Date(max(xa$Date, na.rm=T)),1)
	sessrain[sess,a]<-sum(rain$mm[as.Date(rain$Date) %in% sessrange], na.rm=T)/10}			## rainfall is provided in micrometers
	}
}

sessrain

### Standardise for JAGS ###
rain.capt<-(sessrain-mean(sessrain))/(sd(sessrain))










#############################################################################
##   READ IN WEATHER DATA FROM PITCAIRN IN 2015  ####
#############################################################################
## these data are provided by Pitcairn in an Excel file with two sheets per month
library(readxl)
setwd("A:\\RSPB\\UKOT\\Henderson\\Data\\Weather\\Pitcairn")
setwd("C:\\STEFFEN\\RSPB\\UKOT\\Henderson\\Data\\Weather\\Pitcairn")
files<-list.files(pattern = "\\.xlsx$")	
files[10]

rain<-data.frame()
for (sh in seq(5,10,1)){
shit<-read_excel(files[10], sh,col_names=F,skip=7)
shit<-as.data.frame(shit)
shit<-shit[,1:2]
del<-as.numeric(min(row.names(shit[is.na(shit[,1]),])))
delete<-seq(del,dim(shit)[1],1)
shit<-shit[-(delete),]
shit[,2]<-as.numeric(shit[,2])
shit$Month=sh
rain<-rbind(rain,shit)
}
names(rain)<-c("Day","mm","Month")
rain$Date<-as.POSIXct(paste("2015",rain$Month, rain$Day, sep="-"), format="%Y-%m-%d")


### CALCULATE SUM OF RAINFALL FOR EACH OCCASION AND HABITAT - AS CAPTURE COVARIATE
habs<-c("Beachback","Plateau")
sessrain<-matrix(0,ncol=2,nrow=8)
for (sess in 1:8){
	x<-sessions[sessions$TrapSession==sess,]
 for (a in 1:2){
	xa<-x[x$habitat==habs[a],]
	if(dim(xa)[1]>0){sessrange<-seq.Date(as.Date(min(xa$Date, na.rm=T)),as.Date(max(xa$Date, na.rm=T)),1)
	sessrain[sess,a]<-sum(rain$mm[as.Date(rain$Date) %in% sessrange], na.rm=T)/10}			## rainfall is provided in micrometers
	}
}

sessrain

### Standardise for JAGS ###
rain.capt<-(sessrain-mean(sessrain))/(sd(sessrain))



### CALCULATE SUM OF RAINFALL FOR EACH OCCASION AND HABITAT - AS SURVIVAL COVARIATE
survrain<-matrix(0,ncol=2,nrow=8)
for (sess in 1:7){
	x<-sessions[sessions$TrapSession==sess,]
	x1<-sessions[sessions$TrapSession==sess+1,]
 for (a in 1:2){
	xa<-x[x$habitat==habs[a],]
	if(sess<6){xa1<-x1[x1$habitat==habs[a],]}else{xa1<-x1}
	if(dim(xa)[1]>0){sessrange<-seq.Date(as.Date(min(xa$Date, na.rm=T)),as.Date(min(xa1$Date, na.rm=T)),1)
	survrain[sess,a]<-sum(rain$mm[as.Date(rain$Date) %in% sessrange], na.rm=T)/10}			## rainfall is provided in micrometers
	}
}
survrain[8,]<-sessrain[8,]
survrain

### Standardise for JAGS ###
raininput<-(survrain[,2]-mean(survrain[,2]))/(sd(survrain[,2]))




#### CHECK DAILY CORRELATION OF RAINFALL - VERY POOR ####

str(rain)
str(rainHEN)
rain<-rain[rain$Date %in% rainHEN$Day,]
rainHEN<-rainHEN[rainHEN$Day %in% rain$Date,]
dim(rain)
dim(rainHEN)

plot((rain$mm/10)~rainHEN$SumOfRainfall_mm)
cor.test((rain$mm/10),rainHEN$SumOfRainfall_mm)



#### CHECK CORRELATION OF 10 DAY RAINFALL WINDOWS - PRETTY GOOD ####

starts<-as.Date(rain$Date)[1:52]
raincor<-data.frame(start=starts,PIT=0,HEN=0)

for(per in 1:52){
sessrange<-seq.Date(raincor$start[per],raincor$start[per]+9,1)
raincor$PIT[per]<-sum(rain$mm[as.Date(rain$Date) %in% sessrange], na.rm=T)/10	
raincor$HEN[per]<-sum(rainHEN$SumOfRainfall_mm[as.Date(rainHEN$Day) %in% sessrange], na.rm=T)
}

### REASONABLY GOOD CORRELATION OVER 10 DAY WINDOWS!!
cor.test(raincor$PIT,raincor$HEN)
plot(raincor$PIT~raincor$HEN, pch=16, xlab="Rainfall on Henderson (mm)",ylab="Rainfall on Pitcairn (mm)", cex=1.2, cex.lab=1.5, cex.axis=1.2, las=1)






################################################################################################################
### REMOVE BEACHBACK FROM ALL DATA FRAMES ###
################################################################################################################

rats$area<-trap$area[match(rats$Traploc_ID, trap$Traploc_ID)]
trap<-trap[trap$area=="Plateau",]
rats<-rats[rats$area=="Plateau",]
sessions<-sessions[sessions$habitat=="Plateau",]
rats$area<-NULL
traptypes<-traptypes[traptypes$Traploc_ID %in% trap$Traploc_ID,]

T <- max(rats$TrapSession)   				### number of primary study periods (of 10 trap nights each)
ntraps<-dim(trap)[1]					### number of trap locations	







#############################################################################
##   READ IN SNAP TRAPPING DATA FOR SESSION 8  ####
#############################################################################

setwd("A:\\RSPB\\UKOT\\Henderson\\Data\\Rats")
setwd("C:\\STEFFEN\\RSPB\\UKOT\\Henderson\\Data\\Rats")
files<-list.files(pattern = "\\.xlsx$")	
files[5]

tl<-read_excel(files[5], sheet="TrapData")



## NEED TO MATCH LOCATIONS IN tl TO TRAP LOCATIONS 
tl$Traploc_ID<-NA
for (l in 1: dim(tl)[1]){
matr<-spDistsN1(pts=as.matrix(trap[,4:3]),pt=as.numeric(tl[l,8:7]), longlat = T)
tl$Traploc_ID[l]<-as.character(trap$Traploc_ID[which(matr == min(matr))])
}
head(tl)

## READ IN RAT DATA AND MATCH TO TRAPLOC

krats<-read_excel(files[5], sheet="TrapCaptures")
head(krats)
names(krats)[6]<-"Rat_ID"
krats<-krats[!is.na(krats$Rat_ID),c(1,2,4:6)]
krats<-merge(krats,tl,by=c("TrapLine","TrapNumber"), all.x=T)
dim(krats)


## ADD TO general rats data set
head(rats)
krats$TrapSession<-8
krats$Sex<-ifelse(krats$Condition=="Male",'m','f')
krats$mass<-75			### randomly made up - not used in analysis
krats$Age<-'ad'			### randomly made up - not used in analysis
krats$tail<-55			### randomly made up - not used in analysis
krats$body<-105			### randomly made up - not used in analysis
head(krats)
names(krats)

rats<-rbind(rats,krats[,c(5,3,13,12,14:18)])


### KILLED RATS THAT ARE NOT AVAILABLE IN SPREADSHEED ##

kills<-kills[-(kills$Rat_ID %in% krats$Rat_ID),]
kills$TrapSession<-8
names(kills)[3]<-"Traploc_ID"
head(kills)
rats<-rbind(rats,kills[,c(1,2,10,3:8)])




T <- max(rats$TrapSession)   				### number of primary study periods (of 10 trap nights each)





#############################################################################
##   ADD KILLED RATS TO STATUS MATRIX  ####
#############################################################################

setwd("A:\\RSPB\\UKOT\\Henderson\\Data\\Rats")
setwd("C:\\STEFFEN\\RSPB\\UKOT\\Henderson\\Data\\Rats")
files<-list.files(pattern = "\\.xlsx$")	
files[5]

deadrat<-read_excel(files[5], sheet="Ratdata", skip=1)
head(deadrat)
names(deadrat)[2:7]<-c('Rat_ID','Trap','Sex','status','nipples','pups')

sess8status<- deadrat %>% select(Rat_ID,status,nipples,pups) %>%
	mutate(rep=nipples+pups) %>%
	mutate(rep=if_else(rep>0,2,1)) %>%
	mutate(rep=if_else(is.na(rep),1,2)) %>%
	filter(Rat_ID %in% statmatrix$Rat_ID) %>%
	select(Rat_ID, rep)

statmatrix<- merge(statmatrix, sess8status, by="Rat_ID", all.x=T)
statmatrix[is.na(statmatrix)]<-2				### all NA means the rat was not captured in this session, so doesn't matter what radius we pick
REPinput<-as.matrix(statmatrix[,2:9])

################################################################################################################
##################### ARRANGE TRAP INPUT FILE #########################################################
################################################################################################################

head(trap)
trap<-trap[order(trap$Traploc_ID, decreasing=F),]
trap[is.na(trap)]<-0

### convert lat and long into UTM grid
trapSP<-SpatialPoints(trap[,4:3], proj4string=CRS("+proj=longlat +datum=WGS84"))
trapTransformed<-spTransform(trapSP, CRSobj =CRS("+proj=aeqd"))
trap[,4:3]<-trapTransformed@coords
trap$Longitude<- (trap$Longitude)*(-1)					### because long is on other side of the world, looks mirror-imaged on plot
trap$Longitude<- trap$Longitude-min(trap$Longitude)			### reduce the dimensions of the coordinates to avoid numerical problems
trap$Latitude<- trap$Latitude-min(trap$Latitude)			### reduce the dimensions of the coordinates to avoid numerical problems

### create unique number for each trap
trap$ID<-seq(1:dim(trap)[1])
head(trap)
grid<-as.matrix(trap[,4:3])
plot(grid)


### create matrix with number of trap nights for each trap in each primary period
year<-as.matrix(trap[,5:11])






################################################################################################################
##################### ARRANGE TRAPTYPE INPUT MATRIX #########################################################
################################################################################################################

traptypes<-traptypes[traptypes$Traploc_ID %in% trap$Traploc_ID,]
traptypes$ID<-trap$ID[match(traptypes$Traploc_ID,trap$Traploc_ID)]

traptypes$numtype<-ifelse(traptypes$TrapType=="Sherman",1,2)

ttyp<-cast(traptypes, ID~TrapSession, value='numtype')
ttyp<-as.matrix(ttyp[,c(2:8)])
ttyp[is.na(ttyp)]<-1			### does not work with NA - should not matter because it is not being used anyway


### ADD SNAP TRAPS FOR SESSION 8
ttyp<-cbind(ttyp,rep(3,343))



################################################################################################################
########################## ARRANGE CAPTURE DATA ###################################
################################################################################################################

# remove rat captures without ID
rats<-rats[!is.na(rats$Rat_ID),]
dim(rats)

# remove rat 2603 (marked in BeachBack, killed on Plateau in snap trap)
rats<-rats[!(rats$Rat_ID==2603),]
statmatrix<-statmatrix[!(statmatrix$Rat_ID==2603),]


################################################################################################################
### REMOVE CRAZY MOVERS WITH FEW RECAPTURES  ################################################
################################################################################################################

# remove all 202 rats that were only captured once (transients)
rats$capt<-1
ncapt<-aggregate(capt~Rat_ID, rats, FUN=sum)
hist(ncapt$capt,30)
exclude<-ncapt$Rat_ID[ncapt$capt==1]
dim(rats)
rats<-rats[!(rats$Rat_ID %in% exclude),]
dim(rats)

statmatrix<-statmatrix[!(statmatrix$Rat_ID %in% exclude),]
dim(statmatrix)

# update sex info
rats$Sex[is.na(rats$Sex)]<-'f'
rats$sexnum<-ifelse(rats$Sex=="m",1,2)




################################################################################################################
### CREATE CAPTURE ARRAY FOR TRAPS x INDIVIDUALS x OCCASIONS  ##
################################################################################################################

# sort data and use numeric RatID
rats<-rats[order(rats$Rat_ID, decreasing=F),]
ratids<-unique(rats$Rat_ID)
rats$ID<-match(rats$Rat_ID,ratids)

# match the trap IDs with numeric trap ID
rats$TrapID<-trap$ID[match(rats$Traploc_ID, trap$Traploc_ID)]

# create the data input matrix, which is an array that lists the number of captures of each rat at each trap in each session
rats$capt<-1

y<-array(0,dim=c(max(rats$ID),ntraps,T))						# array for the rat detections
K<-array(0,dim=c(ntraps,T))								# array for the trap deployments

for (p in 1:T){			## start loop over all primary sessions
K[,p]<-trap[,p+4]			## write the activity for all traps into K vector
yp<-cast(rats[rats$TrapSession==p,], formula= ID~TrapID, value='capt', fun.aggregate=sum)		## extract and cast rat captures
trapsused<-seq(1:dim(yp)[2])	## sequential number of the traps in which rats were caught (all others are not in this matrix)

for (m in unique(yp$ID)){			## start loop over all rats captured in this session
ypp<-yp[yp$ID==m,]				## extract all capture locations
ypp2<-as.numeric(ypp)

for (t in names(ypp)[2:length(ypp)]){	## start loop over all capture locations
tn<-as.numeric(t)					## this is the trap number and the index into which the observation has to go into the y array
vecpos<-trapsused[match(t,names(ypp))]	## this is the position in the capture number vector for that individual, matched to the TrapID by vector position
y[m,tn,p]<-ypp2[vecpos]
}							## end loop over capture locations
}							## end loop over individuals
}							## end loop over primary sessions


### DEAL WITH SNAP TRAP SESSION ###
K[,8]<-0
head(tl)
head(trap)
tl$ID<-trap$ID[match(tl$Traploc_ID, trap$Traploc_ID)]
K[tl$ID,8]<-1


### CHECK THAT NO RAT CAUGHT IN SESSION 8 WAS AT A TRAP WITH 0 nights
dim(rats[rats$TrapSession==8,])
length(which(y[,,8]!=0))
test<-melt(y[,,8], fun.aggregate=max)
names(test)<-c("ID","Trap_ID","capt")
testcast<-aggregate(capt~Trap_ID, test,FUN=max)
testcast$K<-K[,8]
testcast$test<-testcast$capt-testcast$K
K[,8]<-apply(testcast[,2:3],1,max)



################################################################################################################
########################## ARRANGE SIZE AND SEX INFORMATION ###################################
################################################################################################################

ALT<-aggregate(sexnum~ID, rats, FUN=min)
body<-aggregate(body~ID, rats, FUN=mean)

## standardize body size ##
body$stand<-(body$body-mean(body$body))/(sd(body$body))
hist(body$stand)

## merge the two

ALT<-merge(ALT, body, by="ID", all.x=T)
ALT$stand[is.na(ALT$stand)]<-0		### set rats with no body length info to 0

## create Animal Lookup Table (ALT) for JAGS TO FIND THE RIGHT INDEX OF SIGMA ###
ALT<-as.matrix(ALT[,c(4,2)])			
dimnames(ALT)<-NULL
dim(ALT)
dim(y)
dim(statmatrix)


### FIND OUT WHICH RAT IS MISSING FROM THE STATUS MATRIX
missrat<-unique(rats$Rat_ID)[which(!(unique(rats$Rat_ID) %in% statmatrix$Rat_ID))]
rats[rats$Rat_ID==missrat,]

################################################################################################################
########### SPECIFY INDIVIDUAL HOME RANGE CENTERS IN FIRST CAPTURE OCCASION ###################################
################################################################################################################

### set the upper and lower x and y coordinates for the state space
xl<- min(trap$Longitude)-150
yl<- min(trap$Latitude)-150
xu<- max(trap$Longitude)+150
yu<- max(trap$Latitude)+150
area<-((xu-xl)*(yu-yl))/10000


### create vector of first capture session and first Home-Range centre
first<-as.numeric()
xl<-as.numeric()
yl<-as.numeric()
xu<-as.numeric()
yu<-as.numeric()
for (i in 1:max(rats$ID)){
first[i]<-min(rats$TrapSession[rats$ID==i])
firstcaploc<-rats$Traploc_ID[rats$ID==i & rats$Date==min(rats$Date[rats$ID==i])]
xl[i]<- trap$Longitude[match(firstcaploc,trap$Traploc_ID)]-50
yl[i]<- trap$Latitude[match(firstcaploc,trap$Traploc_ID)]-50
xu[i]<- trap$Longitude[match(firstcaploc,trap$Traploc_ID)]+50
yu[i]<- trap$Latitude[match(firstcaploc,trap$Traploc_ID)]+50
}



################################################################################################################
### CALCULATE INTERVAL BETWEEN PRIMARY SESSIONS ####
################################################################################################################


sessmidtime<-aggregate(Date~TrapSession, sessions, FUN=mean)
sessmidtime<-rbind(sessmidtime,aggregate(Date~TrapSession, rats[rats$TrapSession==8,], FUN=mean))		### ADD SESSION 8
interval<-vector()
str(sessmidtime)
for (t in 1:(T-1)){
interval[t]<-as.numeric(sessmidtime$Date[t+1]-sessmidtime$Date[t])
}



################################################################################################################
########################## ARRANGE JAGS INPUT DATA ###################################
################################################################################################################


### Set up a data input for JAGS
CJS_data<-list(y=y, M=max(rats$ID), K=K, grid=grid, T=T,ntraps=ntraps, xl=xl,
			yl=yl, xu=xu, yu=yu, first=first, interval=interval, ttyp=ttyp, ALT=ALT,
			rain=raininput, NDVI=NDVIinput$standNDVI[1:7], move.selector=REPinput)





################################################################################################################
########################## CLEAN UP AND SAVE WORKSPACE ###################################
################################################################################################################

### IDENTIFY BIGGEST THINGS IN WORKSPACE AND REMOVE THEM:
WORKSPACE<-data.frame(object=ls(), size=0) 
for (thing in ls()) {
WORKSPACE$size[WORKSPACE$object==thing]<-object.size(get(thing))}

rm(list= ls()[!(ls() %in% c('CJS_data'))])

save.image("C:\\STEFFEN\\RSPB\\UKOT\\Henderson\\Analyses\\Rats\\Bayes_SECR\\Oppel_etal_SECR_INPUT_DATA.RData")





